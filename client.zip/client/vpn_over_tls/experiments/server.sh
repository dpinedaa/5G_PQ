#!/bin/bash

iperf -s