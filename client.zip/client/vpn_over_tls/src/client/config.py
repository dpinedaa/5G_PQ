config = {
	"SERVER_IP": "192.168.122.89",
	"SERVER_PORT": 443,
	"USERNAME": "dmitriy",
	"PASSWORD": "test",
	"TUN_NAME": "tun1",
	"SERVER_HOSTNAME": "strangebit.com",
#        "CA_CERTIFICATE": "./certificates/certchain.pem",
	"CA_CERTIFICATE": "./certificates/certchaindilithium5.pem",
	"BUFFER_SIZE": 1500,
	"DEFAULT_GW": "192.168.122.117",
	"DNS_SERVER": "192.168.122.89"
}
