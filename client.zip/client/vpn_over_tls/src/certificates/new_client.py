import socket
import ssl
from scapy.all import *

HOST = 'localhost'
PORT = 12345

# Create a TCP/IP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Wrap the socket with SSL/TLS
ssl_context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
ssl_context.check_hostname = False
ssl_context.load_verify_locations("dilithium5_PQ.crt")
client_socket = ssl_context.wrap_socket(client_socket, server_hostname=HOST)

# Connect the socket to the server
client_socket.connect((HOST, PORT))

# Send packets to server
while True:
    # Create a packet using Scapy
    packet = IP(dst="1.1.1.1") / ICMP()
    
    # Convert packet to bytes
    packet_bytes = bytes(packet)
    
    # Send the packet through the TLS tunnel
    client_socket.sendall(packet_bytes)

# Close the connection
client_socket.close()
