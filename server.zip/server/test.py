import socket

# Define the server IP address and port
server_ip = '10.0.0.1'
server_port = 7777

# Create a socket object
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to the specified IP address and port
server_socket.bind((server_ip, server_port))

# Start listening for incoming connections (queue up to 5 connections)
server_socket.listen(5)

print(f"Server is listening on {server_ip}:{server_port}")

# Accept incoming connections in an infinite loop
while True:
    # Accept a connection from a client
    client_socket, client_address = server_socket.accept()
    print(f"Connection established with {client_address}")

    # Receive data from the client
    data = client_socket.recv(1024)
    if data:
        print(f"Received message: {data.decode()}")

        # Echo the received data back to the client (optional)
        client_socket.sendall(data)

    # Close the client socket after communication is complete
    client_socket.close()

# Close the server socket (this will only happen if the server exits the infinite loop)
server_socket.close()
