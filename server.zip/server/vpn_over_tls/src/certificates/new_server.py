import socket
import ssl

# Server configuration
SERVER_HOST = '127.0.0.1'
SERVER_PORT = 12345
CERT_FILE = 'dilithium5_PQ.crt'
KEY_FILE = 'dilithium5_PQ.key'

# Create a TCP/IP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to the address and port
server_socket.bind((SERVER_HOST, SERVER_PORT))

# Listen for incoming connections
server_socket.listen(1)

print("Server is listening...")

# Accept incoming connection
connection, client_address = server_socket.accept()

# Wrap the connection with SSL
ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
ssl_context.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)
secure_connection = ssl_context.wrap_socket(connection, server_side=True)

print(f"Connection established with {client_address}")

# Receive and print data from client
while True:
    data = secure_connection.recv(1024)
    if not data:
        break
    print("Received packet:", data)

# Close the connection
secure_connection.close()
