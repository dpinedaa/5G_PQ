import socket
import ssl

HOST = 'localhost'
PORT = 12345

# Create a TCP/IP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Wrap the socket with SSL/TLS
ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
ssl_context.load_cert_chain(certfile="dilithium5_PQ.crt", keyfile="dilithium5_PQ.key")
server_socket = ssl_context.wrap_socket(server_socket, server_side=True)

# Bind the socket to the address and port
server_socket.bind((HOST, PORT))

# Start listening for incoming connections
server_socket.listen(1)

print("Server is listening...")

while True:
    # Accept incoming connection
    conn, addr = server_socket.accept()
    print(f"Connection from {addr}")

    # Receive data from client
    data = conn.recv(1024)
    if not data:
        break
    print(f"Received: {data.decode()}")

    # Send a response back to the client
    conn.sendall(b"Message received by server.")

# Close the connection
conn.close()
