config = {
	"SERVER_IP": "192.168.122.238",
	"SERVER_PORT": 443,
	"USERNAME": "dmitriy",
	"PASSWORD": "test",
	"TUN_NAME": "tun1",
	"SERVER_HOSTNAME": "strangebit.com",
	"CA_CERTIFICATE": "./certificates/certchain.pem",
	"BUFFER_SIZE": 1500,
	"DEFAULT_GW": "192.168.122.238",
	"DNS_SERVER": "192.168.122.91"
}
